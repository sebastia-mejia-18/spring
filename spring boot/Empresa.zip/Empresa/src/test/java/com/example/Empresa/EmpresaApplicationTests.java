package com.example.Empresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
